 
export default function About() {
    return <h1>About News</h1>
  }