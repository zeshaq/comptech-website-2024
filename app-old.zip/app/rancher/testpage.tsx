 
import Image from "next/image";
 

import RancherBanner from "./rancher_banner";
export default function TestPage() {
    return (
 
 <div>asd</div>
    );
  }