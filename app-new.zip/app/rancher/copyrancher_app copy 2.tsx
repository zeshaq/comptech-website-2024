import React from 'react'

const RanchesdfrApp = () => {
  return (
    <div className='p-12'>
<h1 className='text-6xl font-black my-6'>
            Rancher Prime Application Development Engine
</h1>

<div className='grid grid-cols-2 gap-12'>

    <div>
        <h1 className='text-3xl font-black my-4'>

        </h1>
        <p className='text-2xl '>


        </p>
    </div>

    <div>
        <h1 className='text-3xl font-black my-4'>

        </h1>
        <p className='text-2xl '>


        </p>
    </div>

    <div>
        <h1 className='text-3xl font-black my-4'>

        </h1>
        <p className='text-2xl '>


        </p>
    </div>

    <div>
        <h1 className='text-3xl font-black my-4'>

        </h1>
        <p className='text-2xl '>


        </p>
    </div>
</div>
    </div>
  )
}

export default RanchesdfrApp