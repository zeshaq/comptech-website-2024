'use client'
export default function gaga() {
  return <h1>Hello, Next.js!</h1>
}